/////////////////////////////////////////////////////////////////////
// Workspace_eide_352x416/def_platf.h
//
// Copyright (c) Elements Interactive B.V.
// http://www.edgelib.com
//
// Contains specific definitions for this platform
/////////////////////////////////////////////////////////////////////

#define XRES          352
#define YRES          416

#define MOVE_SPEED      6
#define DIM_SPRITE      6
