/////////////////////////////////////////////////////////////////////
// Workspace_eide_176x220/def_platf.h
//
// Copyright (c) Elements Interactive B.V.
// http://www.edgelib.com
//
// Contains specific definitions for this platform
/////////////////////////////////////////////////////////////////////

#define XRES          176
#define YRES          220

#define MOVE_SPEED      3
#define DIM_SPRITE      3
