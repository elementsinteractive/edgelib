/////////////////////////////////////////////////////////////////////
// Workspace_eide_320x208/def_platf.h
//
// Copyright (c) Elements Interactive B.V.
// http://www.edgelib.com
//
// Contains specific definitions for this platform
/////////////////////////////////////////////////////////////////////

#define XRES          320
#define YRES          208

#define MOVE_SPEED      4
#define DIM_SPRITE      4
