/////////////////////////////////////////////////////////////////////
// Workspace_eide_640x200/def_platf.h
//
// Copyright (c) Elements Interactive B.V.
// http://www.edgelib.com
//
// Contains specific definitions for this platform
/////////////////////////////////////////////////////////////////////

#define XRES          640
#define YRES          200

#define MOVE_SPEED      4
#define DIM_SPRITE      4
