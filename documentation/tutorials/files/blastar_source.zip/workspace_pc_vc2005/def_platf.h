/////////////////////////////////////////////////////////////////////
// Workspace_pc_vc2005/def_platf.h
//
// Copyright (c) Elements Interactive B.V.
// http://www.edgelib.com
//
// Contains specific definitions for this platform
/////////////////////////////////////////////////////////////////////

#define XRES          640
#define YRES          480

#define MOVE_SPEED      8
#define DIM_SPRITE      8
