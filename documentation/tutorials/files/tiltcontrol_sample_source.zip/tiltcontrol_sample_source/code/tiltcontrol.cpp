/////////////////////////////////////////////////////////////////////
// Code/tiltcontrol.cpp
// One of the EDGELIB tutorial samples for Windows Mobile
//
// Copyright (c) 2006-2007 Elements Interactive B.V.
// http://www.edgelib.com
//
// Demonstrates the use of the TiltCONTROL device
/////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
// Include and link the library                                    //
/////////////////////////////////////////////////////////////////////

//Include Edge
#include "edgemain.h"

//Link the Edge static library
#pragma comment(lib, "edge.lib")

//Include internal resources
#include "resource.h"

/////////////////////////////////////////////////////////////////////
// Class definition                                                //
/////////////////////////////////////////////////////////////////////

//The main class
class ClassMain : public ClassEdge
{
	private:
		long tiltx;
		long tilty;
		unsigned long score;
		unsigned long highscore;
		long block_x;
		long block_y;
		long block_xvel;
		long block_yvel;
	public:
		ClassMain(void);
		~ClassMain(void);
		ERESULT OnFrameworkConfig(EFRAMEWORKCONFIG *config); 
		ERESULT OnDisplayConfig(EDISPLAYCONFIG *config); 
		ERESULT OnInit(ENATIVETYPE instance);
		ERESULT OnNextFrame(ClassEDisplay *display, unsigned long timedelta);
		void OnExit(ENATIVETYPE instance);
		void OnDeviceTilt(long x, long y);
		void OnButtonDown(unsigned long bnr, EBUTTONLIST *blist);
		void OnStylusDown(POINT pnt);
};


/////////////////////////////////////////////////////////////////////
// ClassMain: public                                               //
/////////////////////////////////////////////////////////////////////

//ClassMain: constructor
ClassMain::ClassMain(void)
{
	tiltx = 0;
	tilty = 0;
	score = 0;
	highscore = 0;
	block_x = 0;
	block_y = 0;
	block_xvel = 0;
	block_yvel = 0;
}

//ClassMain: destructor
ClassMain::~ClassMain(void)
{
}

//Configure framework 
ERESULT ClassMain::OnFrameworkConfig(EFRAMEWORKCONFIG *config) 
{ 
    config->flags |= EFL_NOTILTEMU; 
    return(E_OK); 
} 
  
//Configure display 
ERESULT ClassMain::OnDisplayConfig(EDISPLAYCONFIG *config) 
{ 
    ClassEStd::StrCpy(config->caption, "TiltCONTROL game"); 
    config->icon = IDI_MAIN; 
    return(E_OK); 
} 

//Callback: Called before opening the application
ERESULT ClassMain::OnInit(ENATIVETYPE instance)
{
	ClassEIni ini;
	if (ecd.input->GetTiltData(&ecd) != E_OK)
	{
		SetErrorMsg("TiltCONTROL device not found or not connected.");
		return(E_ERROR);
	}
	if (ini.Open("score.ini"))
	{
		char key[MAX_ESTR], value[MAX_ESTR];
		while (ini.ReadLine(key, value))
		{
			if (ClassEStd::StrEqual(key, "highscore", false))
				highscore = ClassEStd::StrToInt(value);
		}
		ini.Close();
	}
	return(E_OK);
}

//Callback: Called every frame
ERESULT ClassMain::OnNextFrame(ClassEDisplay *display, unsigned long timedelta)
{
	RECT rc;
	long xres = display->buffer.GetWidth();
	long yres = display->buffer.GetHeight();
	long block_unit;
	if (xres < yres)
		block_unit = xres / 24;
	else
		block_unit = yres / 24;

	//Natural decrease of speed
	if (block_xvel > 10 * (long)timedelta)
		block_xvel -= 10 * (long)timedelta;
	else if (block_xvel > 0)
		block_xvel = 0;
	if (block_xvel < 10 * (long)timedelta)
		block_xvel += 10 * (long)timedelta;
	else if (block_xvel < 0)
		block_xvel = 0;
	if (block_yvel > 10 * (long)timedelta)
		block_yvel -= 10 * (long)timedelta;
	else if (block_yvel > 0)
		block_yvel = 0;
	if (block_yvel < 10 * (long)timedelta)
		block_yvel += 10 * (long)timedelta;
	else if (block_yvel < 0)
		block_yvel = 0;

	//Move block
	block_xvel += tiltx * (long)timedelta;
	block_yvel += tilty * (long)timedelta;
	block_x += block_xvel / 16 * (long)timedelta * block_unit / 16;
	block_y += block_yvel / 16 * (long)timedelta * block_unit / 16;

	//Check screen edges
	if ((block_x >> 16) - block_unit / 2 < -xres / 2)
	{
		block_x = (-xres / 2 + block_unit / 2) << 16;
		block_xvel = -block_xvel / 2;
		score /= 2;
	}
	if ((block_x >> 16) + block_unit / 2 > xres / 2)
	{
		block_x = (xres / 2 - block_unit / 2) << 16;
		block_xvel = -block_xvel / 2;
		score /= 2;
	}
	if ((block_y >> 16) - block_unit / 2 < -yres / 2)
	{
		block_y = (-yres / 2 + block_unit) << 16;
		block_yvel = -block_yvel / 2;
		score /= 2;
	}
	if ((block_y >> 16) + block_unit / 2 > yres / 2)
	{
		block_y = (yres / 2 - block_unit / 2) << 16;
		block_yvel = -block_yvel / 2;
		score /= 2;
	}

	//Handle score
	score += abs(block_xvel + block_yvel) * timedelta / 16384;
	if (score > 999999999)
		score = 999999999;
	if (score > highscore)
		highscore = score;

	display->buffer.FillRect(NULL, ECOLOR_BLACK);
	display->buffer.DrawFont(0, 0, &display->fontinternal, tiltx);
	display->buffer.DrawFont(30, 0, &display->fontinternal, tilty);
	display->buffer.DrawFont(0, 14, &display->fontinternal, "Score: ");
	display->buffer.DrawFont(40, 14, &display->fontinternal, score / 16);
	display->buffer.DrawFont(0, 26, &display->fontinternal, "High: ");
	display->buffer.DrawFont(40, 26, &display->fontinternal, highscore / 16);
	long draw_blockx = xres / 2 + (block_x >> 16) - block_unit / 2;
	long draw_blocky = yres / 2 + (block_y >> 16) - block_unit / 2;
	SetRect(&rc, draw_blockx, draw_blocky, draw_blockx + block_unit, draw_blocky + block_unit);
	display->buffer.FillRect(&rc, ECOLOR_WHITE);
	return(E_OK);
}

//Callback: Called before the application quits
void ClassMain::OnExit(ENATIVETYPE instance)
{
	ClassEIni ini;
	if (ini.New("score.ini"))
	{
		ini.WriteComment("Saves the highest score in the TiltCONTROL sample game");
		ini.WriteNewline();
		ini.WriteLine("highscore", highscore);
		ini.Close();
	}
}

//Callback: Called 10 times per second for the state of the TiltCONTROL device
void ClassMain::OnDeviceTilt(long x, long y)
{
	tiltx = x;
	tilty = y;
}

//Callback: Called when the user pressed a key or button
void ClassMain::OnButtonDown(unsigned long bnr, EBUTTONLIST *blist)
{
	Quit();
}

//Callback: Called when the user points the stylus down or clicks the left mouse button
void ClassMain::OnStylusDown(POINT pnt)
{
	Quit();
}


/////////////////////////////////////////////////////////////////////
// The program entry point                                         //
/////////////////////////////////////////////////////////////////////

ClassEdge *EdgeMain(EDGESTARTUP *data){ return(new ClassMain); } 
