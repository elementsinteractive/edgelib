#include <windows.h>
#include <aygshell.h>
#include <tpcuser.h>

#define TPC
