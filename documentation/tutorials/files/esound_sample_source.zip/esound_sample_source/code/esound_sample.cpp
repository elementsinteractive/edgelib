/////////////////////////////////////////////////////////////////////
// Code/esound_sample.cpp
// One of the EDGELIB tutorial samples (multi-platform)
//
// Copyright (c) 2006-2007 Elements Interactive B.V.
// http://www.edgelib.com
//
// Plays music and play sound effects with a button
// Uses ClassESound and the Hekkus Sound System wrapper
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
// Include and link the library                                    //
/////////////////////////////////////////////////////////////////////

//Use the ClassESound Hekkus wrapper
#define ESOUND_HEKKUS

//Include Edge
#include "edgemain.h"

//Link the Edge static library
#pragma comment(lib, "edge.lib")

#if defined(DEVICE_WIN32)

//Include internal resources for native Win32 builds
#include "resource.h"

#else

#define IDI_MAIN 0

#endif


/////////////////////////////////////////////////////////////////////
// Class definition                                                //
/////////////////////////////////////////////////////////////////////

//The main class
class ClassMain : public ClassEdge
{
	public:
		ClassMain(void);
		~ClassMain(void);
		ERESULT OnDisplayConfig(EDISPLAYCONFIG *config);
		ERESULT OnInit(ENATIVETYPE instance);
		ERESULT OnNextFrame(ClassEDisplay *display, unsigned long timedelta);
		void OnButtonDown(unsigned long bnr, EBUTTONLIST *blist);
		void OnStylusDown(POINT pnt);
};


/////////////////////////////////////////////////////////////////////
// ClassMain: public                                               //
/////////////////////////////////////////////////////////////////////

//ClassMain: constructor
ClassMain::ClassMain(void)
{
}

//ClassMain: destructor
ClassMain::~ClassMain(void)
{
}

//Configure display
ERESULT ClassMain::OnDisplayConfig(EDISPLAYCONFIG *config)
{
	ClassEStd::StrCpy(config->caption, "Hekkus Sample");
	config->icon = IDI_MAIN;
	return(E_OK);
}

//Callback: Called before the display mode changes
ERESULT ClassMain::OnInit(ENATIVETYPE instance)
{
	if (ecd.snd->Open() == E_OK)
	{
		ecd.snd->LoadSoundEffect(0, "sound.wav");
		if (ecd.snd->LoadMusic(0, "music.mod") == E_OK)
			ecd.snd->PlayMusic(0, true);
	}
	else
	{
		SetErrorMsg("Error opening sound output");
		return(E_ERROR);
	}
	return(E_OK);
}

//Callback: Called every frame
ERESULT ClassMain::OnNextFrame(ClassEDisplay *display, unsigned long timedelta)
{
	display->buffer.DrawFont(0, 0, &display->fontinternal, "Opened ClassESound...\nUsing Hekkus wrapper");
	display->buffer.DrawFont(0, display->fontinternal.GetHeight() * 3, &display->fontinternal, "A: Play sound effect");
	display->buffer.DrawFont(0, display->fontinternal.GetHeight() * 4, &display->fontinternal, "Any other key: Quit");
	return(E_OK);
}

//Callback: Called when the user pressed a key or button
void ClassMain::OnButtonDown(unsigned long bnr, EBUTTONLIST *blist)
{
	if (bnr == blist->ButtonA)
		ecd.snd->PlaySound(0);
	else
		Quit();
}

//Callback: Called when the user points the stylus down or clicks the left mouse button
void ClassMain::OnStylusDown(POINT pnt)
{
	Quit();
}


/////////////////////////////////////////////////////////////////////
// The program entry point                                         //
/////////////////////////////////////////////////////////////////////

ClassEdge *EdgeMain(EDGESTARTUP *data){ return(new ClassMain); }
