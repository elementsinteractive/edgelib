//Fix for Visual Studio 2005 express

#include <windows.h>
